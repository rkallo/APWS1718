import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
x, y = np.loadtxt('Theorie.txt', unpack=True, delimiter=',')
x *= 1e-3

P = x * y
Ra = y/x

U0 = 1.15655732623
Ri = 4.71986555311

t = np.linspace(0, 60, 1000)
N = U0**2/(t+Ri)**2 * t

plt.plot(t, N, 'b-', label='Theoriekurve')
plt.plot(Ra, P, 'rx', label='Messwerte')
plt.xlabel(r'$R_a / \mathrm{\Omega}$')
plt.ylabel(r'$P / \mathrm {W}$')

plt.legend(loc='best')
plt.grid()

plt.savefig('Theorie.pdf')
